let store = Immutable.Map({
    project:"Mars Dashboard" ,
    rovers: ["Curiosity", "Opportunity", "Spirit"],
    roverName: " ",
});

// add our markup to the page
const root = document.getElementById('root')

const updateStore = (store, newState) => {
    store = Object.assign(store, newState)
    root.innerHTML = displayData2(store);   
}

//rover info
const renderRoverInfo = (store) => {
    const roverData = store.latest_photos;
    const roverDetails = ` 
    <div id="roverInfo">
        <table>
            <tr>
                <th>Name</th>
                <td>${roverData[0].rover.name}</td>
            </tr>
            <tr>
                <th>Launch date</th>
                <td>${roverData[0].rover.launch_date}</td>
            </tr>
            <tr>
                <th>Landing date</th>
                <td>${roverData[0].rover.landing_date}</td>
            </tr>
            <tr>
                <th>Status</th>
                <td>${roverData[0].rover.status}</td>
            </tr>
            <tr>
            <th>Most recent photos taken on</th>
            <td>${roverData.slice(-1).pop().earth_date}</td>
        </tr>
        <tr>
        <th>Name of the camera used</th>
        <td>${roverData[0].camera.name}</td>
    </tr>
        </table>
    </div>
        `;
    return roverDetails;
};
// rover image
const getRoverImage = (store) => {
    const roverData = () => store.latest_photos;
    const roverImg = roverData();
    return roverImg.map(element => {
        return (`
            <div id="img-container">
                <img src="${element.img_src}" id="${element.rover.name.toLowerCase()}-imgg"></img>
            </div>
            `);
    }).join(" ");
};
//Higher order function
const buttonsMenu = () => {
    return (() => {
    const newArray = store.get("rovers");
    return newArray.map((element) => {
        return `<div id="rover">
                <button type="button" id="${element.toLowerCase()}" href=${element} onclick=getRoverData("${element}")><img id="${element.toLowerCase()}-img" src="./assets/images/${element.toLowerCase()}.jpg"></img><p id="${element.toLowerCase()}-p">${element}</p></button>
                </div>
                `;
    });
    })();
};

//display data after load 
const displayData = () => {
    return (`
    <main>
    <header>
    <h1> ${store.get("project")}</h1>
        </header>
        <nav id="nav">
            ${buttonsMenu()}
        </nav> 
    </main>`
)};
//display data after click 
const displayData2 = (store) => {
        return(
            `  <header>
            <h1> ${store.get("project")}</h1>
                </header>
        <div id="dataContainer">
            <div id='roverDetails'>
                ${renderRoverInfo(store)}
            </div>
            <div id='roverPhotos'>
                ${getRoverImage(store)}
            </div>
        </div> 
            `
        )
        }; 
const getRoverData = (roverName) => {
    fetch(`https://api.nasa.gov/mars-photos/api/v1/rovers/${roverName}/latest_photos?api_key=DEMO_KEY`)
        .then(res => res.json())
        .then((roverData) => {
            const latest_photos = roverData.latest_photos;
            updateStore(store, { latest_photos });
        });
};
// listening for load event 
window.addEventListener('load', () => {
    root.innerHTML = displayData();
});
